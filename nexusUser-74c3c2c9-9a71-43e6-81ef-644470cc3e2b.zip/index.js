const AWS = require("aws-sdk");
const cognito = new AWS.CognitoIdentityServiceProvider();
const dynamo = new AWS.DynamoDB.DocumentClient();

const USER_POOL_ID = "ap-south-1_L2Szqa5gw";
const CLIENT_ID = "i9jvq65llrttrui99413oumv7";
const TABLE_NAME = "NexusUsers";

exports.handler = async (event) => {
    const body = JSON.parse(event.body);
    const path = event.resource;
    const method = event.httpMethod;

    try {
        if (path === "/user" && method === "POST") {
            const { name, email, password } = body;

            if (name) {
                // Signup logic
                await cognito.signUp({
                    ClientId: CLIENT_ID,
                    Username: email,
                    Password: password,
                    UserAttributes: [
                        { Name: "email", Value: email },
                        { Name: "name", Value: name }
                    ]
                }).promise();

                // Auto-confirm the user
                await cognito.adminConfirmSignUp({
                    UserPoolId: USER_POOL_ID,
                    Username: email
                }).promise();

                // Store in DynamoDB
                await dynamo.put({
                    TableName: TABLE_NAME,
                    Item: { email, name }
                }).promise();

                return response(201, { message: "Signup successful. User auto-confirmed." });
            } else {
                // Login logic
                const authParams = {
                    AuthFlow: "ADMIN_NO_SRP_AUTH",
                    UserPoolId: USER_POOL_ID,
                    ClientId: CLIENT_ID,
                    AuthParameters: {
                        USERNAME: email,
                        PASSWORD: password
                    }
                };

                const result = await cognito.adminInitiateAuth(authParams).promise();
                return response(200, {
                    message: "Login successful",
                    token: result.AuthenticationResult.IdToken
                });
            }
        }

        if (path === "/user" && method === "GET") {
            const email = event.queryStringParameters.email;

            const result = await dynamo.get({
                TableName: TABLE_NAME,
                Key: { email }
            }).promise();

            return response(200, result.Item || {});
        }

        if (path === "/user" && method === "PUT") {
            const { email, name } = body;

            await dynamo.update({
                TableName: TABLE_NAME,
                Key: { email },
                UpdateExpression: "SET #nm = :n",
                ExpressionAttributeNames: { "#nm": "name" },
                ExpressionAttributeValues: { ":n": name }
            }).promise();

            return response(200, { message: "User updated successfully" });
        }

        if (path === "/user" && method === "DELETE") {
            const email = body.email;

            await dynamo.delete({
                TableName: TABLE_NAME,
                Key: { email }
            }).promise();

            return response(200, { message: "User deleted successfully" });
        }

        return response(404, { error: "Not Found" });

    } catch (err) {
        console.error(err);
        return response(500, { error: err.message || "Server Error" });
    }
};

const response = (statusCode, body) => ({
    statusCode,
    headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
});