import boto3
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    client = boto3.client('quicksight', region_name='ap-south-1')
    
    try:
        response = client.generate_embed_url_for_registered_user(
            AwsAccountId='242201271328',
            UserArn='arn:aws:quicksight:ap-south-1:242201271328:user/default/242201271328',  # 🔁 Replace with your QuickSight user
            SessionLifetimeInMinutes=600,
            ExperienceConfiguration={
                'Dashboard': {
                    'InitialDashboardId': '49469098-a37c-41c4-b570-527bdcdd3277'
                }
            }
        )

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'embedUrl': response['EmbedUrl']})
        }

    except Exception as e:
        logger.exception("Full stack trace error generating embed URL")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'error': str(e)})
        }